
<img src="logo.png" width=200>

_________________________________

#### Current Version:
*v2019.06*

#### Citation:
***Espinoza, *Dupont et al. 2019 (Submitted)

#### Usage:
Documentation and tutorials coming soon.

#### Installation:
conda: https://anaconda.org/jolespin/soothsayer

pip: https://pypi.org/project/soothsayer

Please refer to the [read me](install/README.md) for installation details.

<img src ="https://allpistuff.com/wp-content/uploads/2018/07/twitter.c0030826.jpg" width=100> 
<img src="https://binstar-static-prod.s3.amazonaws.com/latest/img/AnacondaCloud_logo_green.png" width=300>


