Original package:
https://github.com/merenlab/anvio

Original source:
https://github.com/merenlab/anvio/tree/master/anvio/data/hmm/Ribosomal_RNAs

Please cite Anvi'o and the original reference if this is used:
https://doi.org/10.7717/peerj.1319
https://github.com/tseemann/barrnap

Refer to LICENSE.txt for more details.