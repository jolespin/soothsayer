Original package:
https://github.com/merenlab/anvio

Original source:
https://github.com/merenlab/anvio/tree/master/anvio/data/hmm/Protista_83

Please cite Anvi'o and the original reference if this is used:
https://doi.org/10.7717/peerj.1319
http://merenlab.org/delmont-euk-scgs

Refer to LICENSE.txt for more details.