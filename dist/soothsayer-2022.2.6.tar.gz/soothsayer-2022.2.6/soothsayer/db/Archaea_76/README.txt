Original package:
https://github.com/merenlab/anvio

Original source:
https://github.com/merenlab/anvio/tree/master/anvio/data/hmm/Archaea_76

Please cite Anvi'o and the original reference if this is used:
https://doi.org/10.7717/peerj.1319
https://doi.org/10.1093/bioinformatics/btz188

Refer to LICENSE.txt for more details.